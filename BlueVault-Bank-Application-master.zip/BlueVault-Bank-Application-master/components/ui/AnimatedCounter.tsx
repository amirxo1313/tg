'use client';
import React from 'react'
import CountUp from 'react-countup'

const AnimatedCounter = ({ amount }: { amount: number }) => {
  return (
    <div className='w-full'>
      <CountUp 
        duration={2}
        decimals={2} // This ensures that the amount is displayed with 2 decimal places
        decimal='.'
        prefix='$'
        end={amount} 
      />
    </div>
  )
}

export default AnimatedCounter
